// Bu fayl Telegram botning webhook manzili bo'ladi.
// Foydalanuvchi botga /start yozganda, Mini App'ni ochadigan tugma yuboradi.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(200).send("OK");
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const appUrl = process.env.MINI_APP_URL; // masalan: https://your-app.vercel.app

  const update = req.body;
  const msg = update.message;

  if (msg && msg.text) {
    const chatId = msg.chat.id;

    if (msg.text === "/start") {
      await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: "STARS BAZA — Telegram Stars va Premium xarid qilish uchun quyidagi tugmani bosing 👇",
          reply_markup: {
            inline_keyboard: [
              [{ text: "⭐ Ochish", web_app: { url: appUrl } }],
            ],
          },
        }),
      });
    }
  }

  return res.status(200).send("OK");
}
