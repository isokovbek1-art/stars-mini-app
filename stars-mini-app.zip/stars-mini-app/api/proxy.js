// Bu fayl Vercel serverless function sifatida ishlaydi.
// Vazifasi: Mini App'dan kelgan so'rovni qabul qilib, Stars Baza API'siga
// server tarafidan yuboradi (shuning uchun CORS muammosi bo'lmaydi)
// va API kalitni brauzerdan yashiradi.

const API_BASE = "https://stars.cheap-smm.uz/api/v1";

export default async function handler(req, res) {
  // Faqat POST so'rovlarga ruxsat
  if (req.method !== "POST") {
    return res.status(405).json({ status: "error", message: "Faqat POST" });
  }

  const apiKey = process.env.STARS_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ status: "error", message: "Server: STARS_API_KEY sozlanmagan" });
  }

  try {
    const body = { ...req.body, apikey: apiKey };

    const upstream = await fetch(API_BASE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    const data = await upstream.json();
    return res.status(200).json(data);
  } catch (err) {
    return res.status(502).json({
      status: "error",
      message: "Stars Baza serveriga ulanib bo'lmadi: " + err.message,
    });
  }
}
