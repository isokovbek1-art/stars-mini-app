# Stars Baza Mini App — o'rnatish yo'riqnomasi

Bu loyiha 3 qismdan iborat:
- `index.html` — Mini App (foydalanuvchi ko'radigan sahifa)
- `api/proxy.js` — Stars Baza API bilan gaplashadigan proksi (CORS'ni hal qiladi, kalitni yashiradi)
- `api/bot.js` — Telegram bot webhook (foydalanuvchiga "Ochish" tugmasini yuboradi)

## 1-qadam: Vercel'ga ro'yxatdan o'tish

1. https://vercel.com ga kiring, GitHub akkauntingiz bilan ro'yxatdan o'ting (bepul).

## 2-qadam: Loyihani GitHub'ga yuklash

1. https://github.com da yangi repository yarating (masalan `stars-mini-app`).
2. Shu papkadagi barcha fayllarni o'sha repoga yuklang (GitHub saytida "Upload files" tugmasi orqali ham mumkin, git kerak emas).

## 3-qadam: Vercel'da deploy qilish

1. Vercel dashboard'da **"Add New Project"** tugmasini bosing.
2. GitHub repongizni tanlang va **Import** qiling.
3. **Environment Variables** bo'limiga quyidagilarni qo'shing:
   - `STARS_API_KEY` = sizning Stars Baza API kalitingiz
   - `TELEGRAM_BOT_TOKEN` = @BotFather bergan token
   - `MINI_APP_URL` = deploy tugagach beriladigan manzil (masalan `https://stars-mini-app.vercel.app`) — buni birinchi marta bo'sh qoldirib, deploy tugagandan keyin qo'shib, qayta deploy qilsangiz ham bo'ladi.
4. **Deploy** tugmasini bosing. Bir necha soniyada sizga link beriladi, masalan:
   `https://stars-mini-app.vercel.app`

## 4-qadam: Botga webhook o'rnatish

Brauzeringizda quyidagi manzilni oching (TOKEN va APP_URL o'rniga o'zingiznikini qo'ying):

```
https://api.telegram.org/bot<TOKEN>/setWebhook?url=<APP_URL>/api/bot
```

Masalan:
```
https://api.telegram.org/bot123456:ABC-DEF/setWebhook?url=https://stars-mini-app.vercel.app/api/bot
```

Muvaffaqiyatli bo'lsa, `{"ok":true,"result":true,...}` degan javob chiqadi.

## 5-qadam: Sinab ko'rish

Telegram'da botingizga o'ting va `/start` deb yozing. "⭐ Ochish" tugmasi chiqadi — bosganda Mini App ochiladi va u endi haqiqiy API bilan ishlaydi.

## Eslatma

- `MINI_APP_URL` ni to'g'ri qo'yishni unutmang — bo'lmasa tugma ishlamaydi.
- Environment Variable o'zgartirsangiz, Vercel'da qayta **Redeploy** qilish kerak.
- Premium va Sovg'alar hozircha demo rejimda — ularning API `action` nomlarini (Stars Baza hujjatidan) bersangiz, `index.html` dagi `buy()` funksiyasiga qo'shib beraman.
